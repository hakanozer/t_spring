package com.works.onedays.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.onedays.props.Url;
import com.works.onedays.props.User;

@Controller
public class UserController {
	
	List<User> ls = new ArrayList<>();
	
	public UserController() {
		System.out.println("UserController call");
	}
	
	@GetMapping("")
	public String user( Model model, Random rd ) {
		model.addAttribute("name", "Zehra Bilsin");
		model.addAttribute("age", 30);
		model.addAttribute("ls", ls);
		model.addAttribute("uls", urlResult());
		return "user";
	}

	@PostMapping("/userLogin")
	public String userLogin( User us, Model model ) {
		if (us.getUname().equals("") || us.getUpass().equals("")) {
			model.addAttribute("error", "UserName or Password Fail");
			return "user";
		}
		ls.add(us);
		System.out.println("uname " + us.getUname() + " upass " + us.getUpass() );
		return "redirect:/";
	}
	
	
	private List<Url> urlResult() {
		List<Url> uls = new ArrayList<>();
		
		for (int i = 0; i < 10; i++) {
			Url ul = new Url();
			ul.setTitle("Product : " + i);
			ul.setUid(i);
			uls.add(ul);
		}
		
		return uls;
	}
	
	
}
