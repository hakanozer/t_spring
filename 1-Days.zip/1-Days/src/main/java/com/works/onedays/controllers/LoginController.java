package com.works.onedays.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.onedays.props.User;

@Controller
public class LoginController {
	
	static String id = "";
	
	@GetMapping("/login")
	public String login(HttpSession session) {
		id = session.getId();
		return "login";
	}
	
	
	@PostMapping("/loginAdmin")
	public String loginAdmin( User us, HttpSession session ) {
		if(us.getUname().equals("a@a.com") && us.getUpass().equals("12345")) {
			session.setAttribute("user", us.getUname());
			return "redirect:/dashboard";
		}
		return "redirect:/login";
	}
	
	

}
