package com.works.onedays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ProductController {

	@GetMapping("/product/{uid}")
	public String product( @PathVariable int uid, Model model ) {
		System.out.println("uid : " + uid);
		model.addAttribute("uid", uid);
		return "product";
	}
	
}
