package com.works.onedays.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {
	
	
	@GetMapping("/dashboard")
	public String dashboard( HttpSession session ) {

		// session fix control
		String nowID = session.getId();
		System.out.println("old Session : " + LoginController.id);
		System.out.println("new Session : " + nowID);
		if (!nowID.equals(LoginController.id)) {
			// vt log
			return "redirect:/login";
		}

		boolean statu = session.getAttribute("user") == null;
		if(statu) {
			return "redirect:/login";
		}
		return "dashboard";
	}

}
