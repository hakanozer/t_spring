package com.works.fordays.util;

import java.math.BigInteger;
import java.security.MessageDigest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired DriverManagerDataSource db;

	// SQL User Login and Role Control
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		
			auth
			.jdbcAuthentication()
			.dataSource(db)
			.usersByUsernameQuery(" select mail, pass, statu from login where mail = ? ")
			.authoritiesByUsernameQuery(" select mail, role from login where mail = ? ")
			.passwordEncoder( passwordEncoder() );
		
	}
	
	// Web User Role Control
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		http
		.httpBasic()
		.and()
		.authorizeRequests()
		.antMatchers("/user/**").hasRole("user")
		.antMatchers("/product/**").hasRole("product")
		.antMatchers("/bookRest").permitAll()
		.antMatchers("/ws/**").permitAll()
		.and()
		.csrf().disable()
		.formLogin().disable();
		http.headers().frameOptions().disable();

	}
	
	
	
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new PasswordEncoder() {
			
			@Override
			public boolean matches(CharSequence rawPassword, String encodedPassword) {
				return getMd5(rawPassword.toString()).equals(encodedPassword);
			}
			
			@Override
			public String encode(CharSequence rawPassword) {
				return getMd5(rawPassword.toString());
			}
		};
	}
	
	
	public static String getMd5( String input ) {
		
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] mesDiges = md.digest(input.getBytes());
			BigInteger no = new BigInteger(1,mesDiges);
			String hashText = no.toString(16);
			while( hashText.length() < 32 ) {
				hashText = "0" + hashText;
			}
			return hashText;
		} catch (Exception e) {
			return null;
		}
		
	}
	
	
	
}
