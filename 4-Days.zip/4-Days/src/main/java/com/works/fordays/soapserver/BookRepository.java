package com.works.fordays.soapserver;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import https.www_works_com.xml.book.Book;

@Component
public class BookRepository {
	
	@Autowired DriverManagerDataSource db;
	private static Map<Integer, Book> books = new HashMap<>();
	
	@PostConstruct
	public void init() {
		try {
			String query = "select * from product";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				String title = rs.getString("title");
				Book book = new Book();
				book.setId(rs.getInt("pid"));
				book.setTitle(title);
				book.setPages(1000);
				books.put(rs.getInt("pid"), book);
			}
		} catch (Exception e) {
			System.err.println("Db Error : " + e);
		}
	}
	
	
	public Book findBook( int pid ) {
		Assert.notNull(pid, "Book Empty " + pid );
		return books.get(pid);
	}
	
	

}
