package com.works.fordays.soapserver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import https.www_works_com.xml.book.GetBookRequest;
import https.www_works_com.xml.book.GetBookResponse;

@Endpoint
public class BookEndPoint {
	
	@Autowired BookRepository bookRepository;
	private static final String name_space_uri  = "https://www.works.com/xml/book";
	
	@PayloadRoot(namespace = name_space_uri, localPart = "getBookRequest")
	@ResponsePayload
	public GetBookResponse getBook( @RequestPayload GetBookRequest bookRequest ) {
		GetBookResponse bookResponse = new GetBookResponse();
		bookResponse.setBook(bookRepository.findBook(bookRequest.getId()));
		return bookResponse;
	}
	

}
