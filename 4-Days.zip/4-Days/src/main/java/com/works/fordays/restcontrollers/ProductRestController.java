package com.works.fordays.restcontrollers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductRestController {

	@Autowired DriverManagerDataSource db;
	
	@GetMapping("/dbData")
	public Map<String, Object> dbData() {
		Map<String, Object> hm = new LinkedHashMap<>();
		dbResult();
		return hm;
	}
	
	private void dbResult() {
		try {
			String query = "select * from product";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				String title = rs.getString("title");
				System.out.println(title);
			}
		} catch (Exception e) {
			System.err.println("Db Error : " + e);
		}
	}
	
	
}
