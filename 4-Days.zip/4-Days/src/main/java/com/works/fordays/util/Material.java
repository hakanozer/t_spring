package com.works.fordays.util;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

public class Material {
	
	public static String user() {
		
		Authentication aut = SecurityContextHolder.getContext().getAuthentication();
		Collection<? extends GrantedAuthority> cls = aut.getAuthorities();
		for (GrantedAuthority item : cls) {
			System.out.println(item.getAuthority());
		}
		
		System.out.println("Detail : " + aut.getDetails());
		return aut.getName();
	}

}
