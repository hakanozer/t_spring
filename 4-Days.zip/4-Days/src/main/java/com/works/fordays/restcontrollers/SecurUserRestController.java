package com.works.fordays.restcontrollers;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.works.fordays.repositories.UserRepository;
import com.works.fordays.util.Material;

@RestController
@RequestMapping("/user")
public class SecurUserRestController {

	@Autowired UserRepository ur;
	
	@GetMapping("/allUser")
	public Map<String, Object> allUser() {
		System.out.println(Material.user());
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("allUser", ur.findAll());
		return hm;
	}
	
}
