package com.works.fordays.restcontrollers;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.works.fordays.repositories.ProductRepository;
import com.works.fordays.util.Material;

@RestController
@RequestMapping("/product")
public class SecurProductRestController {
	
	@Autowired ProductRepository pr;
	
	@GetMapping("/allProduct")
	public Map<String, Object> allProduct() {
		System.out.println(Material.user());
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("allProduct", pr.findAll());
		return hm;
	}

}
