package com.works.fordays.restcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.works.fordays.soapclient.SoapClient;

import https.www_works_com.xml.book.GetBookRequest;
import https.www_works_com.xml.book.GetBookResponse;

@RestController
public class SoapRestController {
	
	@Autowired SoapClient soapClient;
	
	@GetMapping("/bookRest")
	public GetBookResponse bookRest( @RequestBody GetBookRequest bookRequest ) {
		return soapClient.getBookInfo(bookRequest);
	}
	

}
