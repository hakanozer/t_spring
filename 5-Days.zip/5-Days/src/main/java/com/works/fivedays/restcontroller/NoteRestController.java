package com.works.fivedays.restcontroller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.works.fivedays.model.Note;
import com.works.fivedays.repositories.NoteRepository;

@RestController
public class NoteRestController {

	
	@Autowired NoteRepository nr;
	
	@GetMapping("/allNote")
	public List<Note> allNote() {
		//int i = 1 / 0;
		return nr.findAll();
	}
	
	
	
	@GetMapping("/zipkinRest")
	public Map<String, Object> zipkinRest() {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		String url1 = "http://jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
		String url2 = "http://newsapi.org/v2/top-headlines?sources=google-news-in&apiKey=38a9e086f10b445faabb4461c4aa71f8";
		
		Object data1 = template().getForObject(url1, Object.class);
		Object data2 = template().getForObject(url2, Object.class);
		
		hm.put("data1", data1);
		hm.put("data2", data2);
		
		return hm;
	}
	
	
	@Bean
	public RestTemplate template() {
		RestTemplate rs = new RestTemplate();
		return rs;
	}
	
	
	
}
