package com.works.fivedays.usingprofile;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("word")
public class WordPrintService implements PrintService {

	@Override
	public String print(String name) {
		return "WORD Print " + name;
	}

	
	
}
