package com.works.fivedays.usingprofile;

import org.springframework.stereotype.Component;

@Component
public interface PrintService {

	String print(String name);
	
}
