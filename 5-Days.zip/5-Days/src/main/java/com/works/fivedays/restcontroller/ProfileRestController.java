package com.works.fivedays.restcontroller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.works.fivedays.usingprofile.PrintService;

@RestController
public class ProfileRestController {

	@Autowired private PrintService ps;
	
	@GetMapping("/profile")
	public Map<String, Object> profile( @RequestParam String name ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		String data = ps.print(name);
		hm.put("data", data);
		return hm;
	}
	
}
