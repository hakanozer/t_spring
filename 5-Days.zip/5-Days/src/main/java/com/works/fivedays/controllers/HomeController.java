package com.works.fivedays.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.works.fivedays.model.Note;
import com.works.fivedays.repositories.NoteRepository;

@Controller
public class HomeController {
	
	@Autowired NoteRepository nr;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	
	@PostMapping("/noteInsert")
	@ResponseBody
	public List<Note> noteInsert( @RequestBody Note note ) {
		nr.saveAndFlush(note);
		return nr.findAll();
	}
	
	
	@PostMapping("/noteList")
	@ResponseBody
	public List<Note> noteList( ) {
		return nr.findAll();
	}

}
