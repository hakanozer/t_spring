
create table if not exists city (cid Integer IDENTITY NOT NULL PRIMARY KEY, name varchar not null )