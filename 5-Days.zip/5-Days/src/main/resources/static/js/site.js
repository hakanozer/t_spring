
setInterval(function(){ 
		//noteList();
	}, 3000);

function fncSend() {
	
	const ntitle = $("#ntitle").val();
	const ndesc = $("#ndesc").val();
	const ndate = $("#ndate").val();
	
	const dt = {
		"ntitle": ntitle,
		"ndesc": ndesc,
		"ndate": ndate
	}
	
	$.ajax({
		type: "post",
		contentType: "application/json",
		url: "/noteInsert",
		data: JSON.stringify(dt),
		dataType: "json",
		success: function(data) {
			console.log(JSON.stringify(data))
			rowsResult(data)
		},
		error: function(error) {
			console.log("error call " + error)
		}
	})

}

noteList();
function noteList() {
	$.ajax({
		type: "post",
		contentType: "application/json",
		url: "/noteList",
		success: function(data) {
			rowsResult(data)
		},
		error: function(error) {
			console.log("error call " + error)
		}
	})
}

function rowsResult( data ) {
	var rw = ""
	data.forEach( item => {
		rw += `<tr>
			      <th>`+item.nid+`</th>
			      <td>`+item.ntitle+`</td>
			      <td>`+item.ndesc+`</td>
			      <td>`+item.ndate+`</td>
			    </tr>` 
	})
	
	$("#rows").html(rw);
}


