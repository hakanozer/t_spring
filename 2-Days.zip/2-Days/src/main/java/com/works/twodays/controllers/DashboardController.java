package com.works.twodays.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.works.twodays.tools.Util;

@Controller
public class DashboardController {

	@GetMapping("/dashboard")
	public String dashboard( HttpServletRequest req ) {
		return Util.control("dashboard", req);
	}
	
	@PostMapping("/userSendData")
	public String userSendData( HttpServletRequest req, @RequestParam String name, Model model ) {
		System.out.println("name : " + name);
		model.addAttribute("name", name);
		return Util.control("dashboard", req); 
	}
	
	
}
