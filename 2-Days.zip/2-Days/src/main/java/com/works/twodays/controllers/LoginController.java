package com.works.twodays.controllers;

import java.util.Optional;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.works.twodays.model.User;
import com.works.twodays.repositories.UserRepository;
import com.works.twodays.tools.Util;

@Controller
public class LoginController {
	
	@Autowired UserRepository urepo;

	@GetMapping("")
	public String login() {
		// vtuser = null;
		return "login";
	}
	
	//User vtuser= null;
	@PostMapping("/login")
	public String fncLogin( HttpServletRequest req, HttpServletResponse res, User us, @RequestParam(defaultValue = "off") String remember_me ) {
		String m = us.getEmail();
		String p = Util.MD5(us.getPass());
		
		/*
		vtuser = null;
		Pageable limit = PageRequest.of(0, 10);
		urepo.findAll(limit).stream()
		.filter(item -> item.getEmail().equals(m) && item.getPass().equals(p))
		.forEach(item -> {
			vtuser = item;
		});
		*/
		
		 Optional<User> usx = urepo.findAll().stream()
		.filter(item -> item.getEmail().equals(m) && item.getPass().equals(p))
		.findAny();
		 usx.ifPresent(item -> {
			 System.out.println(item.getName() + " " + item.getUid());
		 });
		 
		 if (usx.isPresent()) {
			 // user login success
			 req.getSession().setAttribute("user", usx.get().getUid());
			 req.getSession().setAttribute("userName", usx.get().getName());
			 
			 // cookie control
			 if (remember_me.equals("on")) {
				 Cookie cookie = new Cookie("user", Util.sifrele(""+usx.get().getUid(), 3));
				 cookie.setMaxAge(60 * 60 * 24);
				 res.addCookie(cookie);
			 }
			 
			 // redirect
			 return "redirect:/dashboard";
			 
		 }

		/*
		if (vtuser != null ) {
			System.out.println(vtuser.getName() + " " + vtuser.getUid());
		}
		*/

		System.out.println(m + " " + p);
		return "login";
	}
	
	
	@GetMapping("/exit")
	public String exit( HttpServletRequest req, HttpServletResponse res ) {
		req.getSession().invalidate();
		req.getSession().removeAttribute("user");
    	// cookie remove
    	Cookie cookie = new Cookie("user", "");
    	cookie.setMaxAge(0);
    	res.addCookie(cookie);
    	// Redirect
		return "redirect:/";
	}
	
	
	
}
