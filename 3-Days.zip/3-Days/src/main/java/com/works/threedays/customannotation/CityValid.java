package com.works.threedays.customannotation;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CityValid implements ConstraintValidator<City, String> {

	List<String> cls = Arrays.asList("Adana","İstanbul","Bursa","İzmir","Ankara");
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return cls.contains(value);
	}
	
	

}
