package com.works.threedays.rssController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.feed.AbstractRssFeedView;

import com.rometools.rome.feed.rss.Channel;
import com.rometools.rome.feed.rss.Description;
import com.rometools.rome.feed.rss.Image;
import com.rometools.rome.feed.rss.Item;
import com.works.threedays.model.Product;
import com.works.threedays.repositories.ProductRepository;

@Component
public class RssFeedView extends AbstractRssFeedView {
	
	@Autowired ProductRepository pr;

	@Override
	protected void buildFeedMetadata(Map<String, Object> model, Channel feed, HttpServletRequest request) {
		
		feed.setTitle("Rss Title Info");
		feed.setDescription("RSS is a fascinating technology.");
		feed.setPubDate(new Date());
		feed.setLink("https://google.com.tr");
		
		Image img = new Image();
		img.setUrl("https://cdn4.iconfinder.com/data/icons/winter-1-2/512/Winter-27-512.png");
		img.setTitle("Home Icon");
		feed.setImage(img);
		
	}
	
	
	@Override
	protected List<Item> buildFeedItems(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		List<Item> ls = new ArrayList<Item>();
		List<Product> pls = pr.findAll();
		for (Product item : pls) {
			Item it =  new Item();
			it.setTitle(item.getTitle());
			it.setUri(""+item.getPid());
			
			Description description = new Description();
			description.setType("brief");
			description.setValue(item.getBrief());
			it.setDescription(description);
			
			Description description2 = new Description();
			description2.setType("price");
			description2.setValue(""+item.getPrice());
			it.setDescription(description2);
			
			ls.add(it);
		}
		
		return ls;
	}
	
}
