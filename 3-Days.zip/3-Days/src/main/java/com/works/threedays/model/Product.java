package com.works.threedays.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import com.works.threedays.customannotation.City;
import com.works.threedays.customannotation.CityValid;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pid;
	
	@NotNull(message = "Title Not Null")
	@NotEmpty(message = "Title Not Empty")
	@Length( min = 3, max = 30, message = "Min 3 Max 30" )
	private String title;
	
	@NotNull(message = "brief Not Null")
	@NotEmpty(message = "brief Not Empty")
	private String brief;
	
	@Range(min = 5, max = 999, message = "price min 1 max 999 " )
	private double price;
	
	@City(message = "City not found")
	private String ucity;

	
	public String getUcity() {
		return ucity;
	}
	public void setUcity(String ucity) {
		this.ucity = ucity;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	
}
