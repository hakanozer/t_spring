package com.works.threedays.restcontrollers;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.works.threedays.model.Product;
import com.works.threedays.repositories.ProductRepository;

@RestController
//@RequestMapping("/product")
public class ProductRestController {
	
	@Autowired ProductRepository pr;
	
	@PostMapping("/productInsert")
	public Map<String, Object> productInsert( Product pro ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		Product product = pr.saveAndFlush(pro);
		hm.put("statu", true);
		hm.put("product", product);
		return hm;
	}
	
	
	// json insert
	// BindingResult result
	@PostMapping("/productInsertJson")
	public Map<String, Object> productInsertJson( @Valid @RequestBody Product pro ) {
		/*
		List<ObjectError> ls = result.getAllErrors();
		if (ls.size() > 0) {
			System.out.println("Product Error");
		}*/
		
		Map<String, Object> hm = new LinkedHashMap<>();
		Product product = pr.saveAndFlush(pro);
		hm.put("statu", true);
		hm.put("product", product);
		return hm;
	}
	
	
	@GetMapping("/productList")
	@Cacheable("productList")
	//@Scheduled(fixedDelay = 1000, initialDelay = 1000 )
	public Map<String, Object> productList( ) {
		System.out.println(" productList call");
		Map<String, Object> hm = new LinkedHashMap<>();
		List<Product> ls = pr.findAll();
		hm.put("list", ls);
		return hm;
	}
	
	
	@GetMapping("/productListPrice")
	public Map<String, Object> productListPrice( double price ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		List<Product> ls = pr.fncSearchPrice(price);
		hm.put("list", ls);
		return hm;
	}
	
	
	
	@PutMapping("/productUpdate")
	public Map<String, Object> productUpdate( Product pro ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		
		Optional<Product> vpr = pr.findById(pro.getPid());
		vpr.get().setTitle(pro.getTitle());
		
		Product product = pr.saveAndFlush(vpr.get());
		hm.put("statu", true);
		hm.put("update", product);
		return hm;
	}
	
	
	@DeleteMapping("/productDelete")
	public Map<String, Object> productDelete( int pid ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		try {
			pr.deleteById(pid);
			hm.put("statu", true);
		} catch (Exception e) {
			hm.put("statu", false);
		}
		
		return hm;
	}
	
	
	
	@ResponseStatus( code = HttpStatus.BAD_REQUEST )
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleFnc( MethodArgumentNotValidException ex ) {
		Map<String, String> hm = new HashMap<>();
		
		List<ObjectError> err = ex.getBindingResult().getAllErrors();
		int i = 0;
		for (ObjectError item : err) {
			i++;
			String filed = ((FieldError) item).getField();
			String message = item.getDefaultMessage();
			hm.put(filed + i, message);
		}
		
		return hm;
	}
	
	

}
