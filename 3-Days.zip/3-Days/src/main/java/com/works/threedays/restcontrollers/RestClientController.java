package com.works.threedays.restcontrollers;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.works.threedays.model.Article;
import com.works.threedays.model.JsonData;

@RestController
public class RestClientController {

	@GetMapping("/news")
	public Map<String, Object> news(String data) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("news", newsResult(data));
		return hm;
	}

	
	private List<Article> newsResult(String data) {
		
		String url = "http://newsapi.org/v2/everything?q="+data+"&from=2020-07-19&sortBy=publishedAt&apiKey=38a9e086f10b445faabb4461c4aa71f8";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> stringData = restTemplate.getForEntity(url, String.class);
		
		Gson gson = new Gson();
		JsonData jd = gson.fromJson(stringData.getBody(), JsonData.class);
		if (jd.getTotalResults() > 0) {
			return jd.getArticles();
		}
		return null;
		
	}
	
	
	
}
