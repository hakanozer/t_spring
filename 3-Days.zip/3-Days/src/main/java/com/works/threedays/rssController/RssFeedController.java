package com.works.threedays.rssController;

import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.View;

import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.SyndFeedInput;
import com.rometools.rome.io.XmlReader;

@RestController
public class RssFeedController {

	@Autowired RssFeedView view;
	
	@GetMapping("/rss")
	public View getFeed() {
		return view;
	}
	
	
	// Rss Client
	@GetMapping("/rssClient")
	public Map<String, Object> rssClient() {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("rssResult", rssResult());
		return hm;
	}
	
	
	private List<SyndEntry> rssResult() {
		
		String url = "https://www.feedforall.com/sample.xml";
		try ( XmlReader reader = new XmlReader(new URL(url)) ) {
			
			SyndFeed feed = new SyndFeedInput().build(reader);
			String title = feed.getTitle();
			System.out.println("Title : " + title);
			List<SyndEntry> entries = feed.getEntries();
			for (SyndEntry item : entries) {
				System.out.println(item);
			}
			return entries;
			
		}catch (Exception e) {
			System.err.println("xml Error : " + e);
		}
		return null;
	}
	
	
}
